import requests

BASE_URL = "http://127.0.0.1:8000"


def test_submit_feedback_already_submitted(auth_headers):
    """
    Verify that submitting feedback again for a complaint
    that already has feedback returns a conflict response.
    """

    # Input
    endpoint = "/complaints/CMP-65C600/feedback"

    payload = {
        "rating": 5,
        "comments": "Nice work"
    }

    # Expected Output
    expected_status = 409

    # Actual Output
    response = requests.post(
        f"{BASE_URL}{endpoint}",
        json=payload,
        headers=auth_headers
    )

    actual_status = response.status_code

    # Assertion
    assert actual_status == expected_status, (
        f"\nTest Case       : Submit Duplicate Feedback"
        f"\nInput           : POST {endpoint}"
        f"\nExpected Output : HTTP Status {expected_status}"
        f"\nActual Output   : HTTP Status {actual_status}"
        f"\nResponse        : {response.text}"
    )

    # Verify the actual error message
    response_data = response.json()

    assert response_data["detail"] == (
        "You have already submitted feedback for this complaint."
    ), (
        f"\nExpected Message : "
        f"You have already submitted feedback for this complaint."
        f"\nActual Message   : {response_data.get('detail')}"
    )