import requests

BASE_URL = "http://127.0.0.1:8000"


def test_get_categories_requires_auth():
    """
    Verify that the Categories endpoint is protected
    and requires authentication.
    """

    # Input
    endpoint = "/categories"

    # Expected Output
    expected_status = [200, 401, 403]

    # Actual Output
    response = requests.get(f"{BASE_URL}{endpoint}")
    actual_status = response.status_code

    # Assertion
    assert actual_status in expected_status, (
        f"\nTest Case       : Get Categories Authentication"
        f"\nInput           : GET {endpoint}"
        f"\nExpected Output : HTTP Status {expected_status}"
        f"\nActual Output   : HTTP Status {actual_status}"
    )


def test_recategorize_complaint(admin_auth_headers):
    """
    Verify that an administrator can recategorize
    an existing complaint.
    """

    # Input
    endpoint = "/complaints/CMP-65C600/category"

    payload = {
        "categoryId": "CAT-ELE-01"
    }

    # Expected Output
    expected_status = 200

    # Actual Output
    response = requests.patch(
        f"{BASE_URL}{endpoint}",
        json=payload,
        headers=admin_auth_headers
    )

    actual_status = response.status_code

    # Assertion
    assert actual_status == expected_status, (
        f"\nTest Case       : Recategorize Complaint"
        f"\nInput           : PATCH {endpoint}"
        f"\nExpected Output : HTTP Status {expected_status}"
        f"\nActual Output   : HTTP Status {actual_status}"
        f"\nResponse        : {response.text}"
    )

    # Verify the actual category in the response
    response_data = response.json()

    assert response_data["category"]["categoryId"] == "CAT-ELE-01", (
        f"\nExpected Category : CAT-ELE-01"
        f"\nActual Category   : "
        f"{response_data.get('category', {}).get('categoryId')}"
    )