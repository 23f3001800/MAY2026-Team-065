import requests

BASE_URL = "http://127.0.0.1:8000"


def test_admin_analytics_requires_auth():
    """
    Verify that the Admin Analytics endpoint is protected
    and requires authentication.
    """

    # Input
    endpoint = "/admin/analytics"

    # Expected Output
    expected_status = [200, 401, 403]

    # Actual Output
    response = requests.get(f"{BASE_URL}{endpoint}")
    actual_status = response.status_code

    # Assertion
    assert actual_status in expected_status, (
        f"\nTest Case       : Admin Analytics Authentication"
        f"\nInput           : GET {endpoint}"
        f"\nExpected Output : HTTP Status {expected_status}"
        f"\nActual Output   : HTTP Status {actual_status}"
    )

def test_get_admin_analytics(admin_auth_headers):
    """
    Verify that an authenticated administrator can retrieve
    city-level analytics.
    """

    # Input
    endpoint = "/admin/analytics"

    # Expected Output
    expected_status = 200

    # Actual Output
    response = requests.get(
        f"{BASE_URL}{endpoint}",
        headers=admin_auth_headers
    )

    actual_status = response.status_code

    # Assertion
    assert actual_status == expected_status, (
        f"\nTest Case       : Get Admin Analytics"
        f"\nInput           : GET {endpoint}"
        f"\nExpected Output : HTTP Status {expected_status}"
        f"\nActual Output   : HTTP Status {actual_status}"
        f"\nResponse        : {response.text}"
    )

    # Basic response validation
    assert response.json() is not None

